# quizcosemssc
QUIZ para uso no totem do COSEMS/SC 2023

1. Modernize Free: https://github.com/adminmart/Modernize-bootstrap-free
2. SweetAlert2: https://sweetalert2.github.io/
