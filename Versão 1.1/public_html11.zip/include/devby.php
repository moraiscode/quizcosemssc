<div class="py-6 px-6 text-center">
    <div class="p-3"></div>
    <p class=""><small>CFN®
            <?php echo date("Y"); ?> | Desenvolvido por 💻 <a href="https://moraiscode.com/" target="_blank"
                class="pe-1 text-primary font-weight-bold">Felipe Morais ;)</a>
        </small>
    </p>
</div>